<div class="container">
   <div class="row">
   <hr>
      <p class="text-center">All rights belong exclusively to @salmanxk (2016).</p>
   </div>
</div>