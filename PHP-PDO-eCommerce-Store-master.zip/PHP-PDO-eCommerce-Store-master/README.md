# A simple PHP eCommerce Store
## Why use PDO? (PHP Data Objects)
This is so because the legacy mySQL has been replaced by mySQLi and PDO.
There are virtually no proper tutorials or websites demonstrating how to use PDO available either. Hence this is also my attempt to learn PDO as well.
NOTE: Do keep in mind that I was never much good at the legacy mySQL either, so please don't hold it against me!

## How to run
Copy all files to your server root directory(or the 'htdocs' if you are using XAMPP). 

Import the 'store\_db.sql' file into your server's mysql installation. The database name is store\_db.

_**WARNING**: the store db file is currently out of date! It might pose a problem so proceed with caution._

UI Inspiration: https://blackrockdigital.github.io/startbootstrap-shop-homepage/
