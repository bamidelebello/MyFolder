@author Shahrukh Khan
@website www.thesoftwareguy.in
@project Simple address book with php and mysql using pdo
***********************************************************
To run this project do the following steps:
1. Go to your htdocs/www/public_html folder.
2. Create a folder name address-book.
3. Go to your phpmyadmin and execute the script in address_book.sql either directly or use import method.
   It will create database automatically and import the scheme with dummy records.
4. In case you have other user other than root go to config.php and do the following.
   define('DB_SERVER_USERNAME', 'your username here');
   define('DB_SERVER_PASSWORD', 'your password here');
   define('DB_DATABASE', 'your database name here');

   Good Luck for your projects. Feel free to post your comments on my blog.
